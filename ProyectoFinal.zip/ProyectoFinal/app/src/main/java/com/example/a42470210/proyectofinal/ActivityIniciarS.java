package com.example.a42470210.proyectofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ActivityIniciarS extends AppCompatActivity {

    public void Volver (View Vista){
        Intent Inicio;
        Inicio = new Intent(ActivityIniciarS.this, ActivityInicial.class);
        startActivity(Inicio);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar_s);
    }
}
