package com.example.a42470210.proyectofinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ActivityInicial extends AppCompatActivity {

    public void Registrarse (View Vista){
        Intent Registracion;
        Registracion = new Intent (ActivityInicial.this, ActivityRegis.class);
        startActivity(Registracion);
    }

    public void IniciarSesion (View Vista){
        Intent IniciarS;
        IniciarS = new Intent (ActivityInicial.this, ActivityIniciarS.class);
        startActivity(IniciarS);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicial);
            }
}
